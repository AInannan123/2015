import streamlit as st
import plotly.express as px
import time
from PIL import Image
import folium
from streamlit_folium import folium_static

# 设置页面标题
st.set_page_config(page_title="热带雨林固碳模型", page_icon="🌳", layout="wide")

# 标题和说明
st.title("🌳 热带雨林固碳模型")
st.markdown("这是一个基于光合作用原理的热带雨林固碳模型，用于计算森林的年固碳量和氧气释放量。")

# 添加图片
image = Image.open("forest.jpg")
st.image(image, caption="热带雨林", use_column_width=True)

# 分栏布局
col1, col2 = st.columns(2)

with col1:
    st.header("参数设置")
    light = st.slider("光照强度 (lux)", 0, 10000, 5000)
    co2 = st.slider("二氧化碳浓度 (ppm)", 0, 1000, 400)
    water = st.slider("水分供应 (mm)", 0, 1000, 500)
    area = st.slider("森林面积 (公顷)", 0, 10000, 1000)
    temperature = st.slider("温度 (℃)", 0, 40, 25)
    forest_type = st.selectbox("森林类型", ["热带雨林", "温带森林", "寒带森林"])

with col2:
    st.header("计算结果")
    if forest_type == "热带雨林":
        k = 0.01
    elif forest_type == "温带森林":
        k = 0.008
    else:
        k = 0.005

    with st.spinner("计算中..."):
        time.sleep(2)
        carbon_capture = k * light * co2 * water * area
        oxygen_release = carbon_capture * 0.75
    st.success("计算完成！")
    st.write(f"年固碳量: {carbon_capture:.2f} 吨")
    st.write(f"年氧气释放量: {oxygen_release:.2f} 吨")

    # 显示动态公式
    st.latex(r"\text{固碳量} = k \times \text{光照强度} \times \text{二氧化碳浓度} \times \text{水分} \times \text{森林面积}")
    st.write(f"当前固碳系数 k = {k}")

# 使用 Plotly 生成图表
fig = px.bar(
    x=['固碳量', '氧气释放量'],
    y=[carbon_capture, oxygen_release],
    labels={'x': '类型', 'y': '吨/年'},
    title="森林固碳与氧气释放"
)
fig.update_traces(marker_color=['green', 'blue'])
st.plotly_chart(fig)

# 添加地图
st.header("热带雨林分布")
m = folium.Map(location=[-3, -60], zoom_start=4)  # 亚马逊雨林位置
folium.Marker([-3, -60], popup="亚马逊雨林").add_to(m)
folium_static(m)